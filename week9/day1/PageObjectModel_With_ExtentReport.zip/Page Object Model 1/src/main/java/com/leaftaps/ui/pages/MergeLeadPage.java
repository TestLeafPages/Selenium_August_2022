package com.leaftaps.ui.pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import com.leaftaps.ui.base.ProjectSpecificMethods;

public class MergeLeadPage extends ProjectSpecificMethods {

	public MergeLeadPage(RemoteWebDriver recievedDriver) {
		this.driver = recievedDriver;
	}
	
	

}
