package com.leaftaps.ui.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import com.leaftaps.ui.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {

	public LoginPage(RemoteWebDriver recievedDriver) {
		this.driver = recievedDriver;
	}
	
	public LoginPage enterUsername(String username) throws IOException {
		try {
			driver.findElement(By.id("username")).sendKeys(username);
			reportStep(username+" Username is entered successfully","pass");
		} catch (Exception e) {
			reportStep("Username is not entered successfully..."+e,"fail");
		}
		return this;
	}
	
	public LoginPage enterPassword(String password) throws IOException {
		try {
			driver.findElement(By.id("password")).sendKeys(password);
			reportStep(password+" password is entered successfully","pass");
		} catch (Exception e) {
			reportStep("Password is not entered successfully..."+e,"fail");
		}
		return this;
	}
	
	public WelcomePage clickLogin_positive() throws IOException {
		try {
			driver.findElement(By.className("decorativeSubmit")).click();
			reportStep("Login button is clicked", "pass");
		} catch (Exception e) {
			reportStep("Login button is not clicked..."+e, "fail");
		}
		return new WelcomePage(driver);
	}
	
	public LoginPage clickLogin_negative() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return this;
	}

}
